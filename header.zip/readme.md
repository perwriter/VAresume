![banner](./banner.png)

## HTML CSS Resume

 built in HTML CSS only!

**Live Preview: https://virtualassistant.perwriters.com/

---